﻿using System;

namespace CalculatorProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Läs in priset på varan

            Console.Write("Ange pris: ");
            int price = int.Parse(Console.ReadLine());

            // Läs in beloppet som kunden har betalat

            Console.Write("Betalt: ");
            int paid = int.Parse(Console.ReadLine());

            // Beräkna växeln som ska ges tillbaka

            int change = paid - price;

            // Kontrollera om kunden betalat mindre än priset

            if (change < 0)
            {
                Console.WriteLine("Inte tillräckligt betalning. Var god betala hela beloppet.");
                return;
            }

            // Skapa variabler för att hålla koll på antalet sedlar och mynt som ska ges tillbaka

            int twoHundreds = 0;
            int hundreds = 0;
            int fifties = 0;
            int twenties = 0;
            int tens = 0;
            int fives = 0;
            int ones = 0;

            // Dela upp växeln i antalet sedlar och mynt av olika valörer som ska ges tillbaka

            twoHundreds = change / 200;
            change = change % 200;
            hundreds = change / 100;
            change = change % 100;
            fifties = change / 50;
            change = change % 50;
            twenties = change / 20;
            change = change % 20;
            tens = change / 10;
            change = change % 10;
            fives = change / 5;
            change = change % 5;
            ones = change;

            // Skriv ut växeln som ska ges tillbaka
            Console.WriteLine("Växel tillbaka: ");
            if (twoHundreds > 0) Console.WriteLine(twoHundreds + " tvåhundralapp(ar)");
            if (hundreds > 0) Console.WriteLine(hundreds + " hundralapp(ar)");
            if (fifties > 0) Console.WriteLine(fifties + " femtiolapp(ar)");
            if (twenties > 0) Console.WriteLine(twenties + " tjugolapp(ar)");
            if (tens > 0) Console.WriteLine(tens + " tioöring(ar)");
            if (fives > 0) Console.WriteLine(fives + " femöring(ar)");
            if (ones > 0) Console.WriteLine(ones + " enöring(ar)");
        }
    }
}

