﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.lblnewone = new System.Windows.Forms.Label();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.paidBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.closeBtn1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(502, 40);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(176, 80);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "OK";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // lblnewone
            // 
            this.lblnewone.AutoSize = true;
            this.lblnewone.Location = new System.Drawing.Point(103, 196);
            this.lblnewone.Name = "lblnewone";
            this.lblnewone.Size = new System.Drawing.Size(33, 16);
            this.lblnewone.TabIndex = 2;
            this.lblnewone.Text = "SEK";
            // 
            // priceBox
            // 
            this.priceBox.Location = new System.Drawing.Point(106, 37);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(157, 22);
            this.priceBox.TabIndex = 3;
            // 
            // paidBox
            // 
            this.paidBox.Location = new System.Drawing.Point(106, 92);
            this.paidBox.Name = "paidBox";
            this.paidBox.Size = new System.Drawing.Size(157, 22);
            this.paidBox.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ange Pris";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Betalt";
            // 
            // closeBtn1
            // 
            this.closeBtn1.Location = new System.Drawing.Point(502, 161);
            this.closeBtn1.Name = "closeBtn1";
            this.closeBtn1.Size = new System.Drawing.Size(176, 64);
            this.closeBtn1.TabIndex = 7;
            this.closeBtn1.Text = "Avsluta";
            this.closeBtn1.UseVisualStyleBackColor = true;
            this.closeBtn1.Click += new System.EventHandler(this.closeBtn1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Växel Tillbaka";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.closeBtn1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.paidBox);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.lblnewone);
            this.Controls.Add(this.btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Label lblnewone;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.TextBox paidBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button closeBtn1;
        private System.Windows.Forms.Label label3;
    }
}

