﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            // Ta in priset och betalningen från användaren och beräkna växeln
            int price = int.Parse(priceBox.Text);// Konvertera priset från sträng till heltal
            int paid = int.Parse(paidBox.Text);// Konvertera betalningen från sträng till heltal
            int change = paid - price;// Beräkna skillnaden mellan betalningen och priset


            // Visa meddelande om inte tillräckligt betalt
            if (change < 0)
            {
                lblnewone.Text = "Inte tillräckligt betalning.\n Var god betala hela beloppet.";
            }

            // Räkna ut och visa växel
            else if (change > 0)
            {
                int twoHundred = change / 200;// Räkna antal 200-lappar som ska ges tillbaka
                change = change % 200;// Uppdatera växelsumman

                int hundreds = change / 100;
                change = change % 100;

                int fifties = change / 50;
                change = change % 50;

                int twenties = change / 20;
                change = change % 20;

                int tens = change / 10;
                change = change % 10;

                int fives = change / 5;
                change = change % 5;

                int onecoins = change;

                // Bygg en sträng med information om vilka valörer som ska ges tillbaka och hur många
                string vaxelText = "\r\n";

                if (twoHundred > 0)
                {
                    vaxelText += twoHundred + " tvåhundralapp(ar)\r\n";
                }
                if (hundreds > 0)
                {
                    vaxelText += hundreds + " hundralapp(ar)\r\n";
                }
                if (fifties > 0)
                {
                    vaxelText += fifties + " femptiolapp(ar)\r\n";
                }
                if (twenties > 0)
                {
                    vaxelText += twenties + " tjugolapp(ar)\r\n";
                }
                if (tens > 0)
                {
                    vaxelText += tens + " tioöring(ar)\r\n";
                }
                if (fives > 0)
                {
                    vaxelText += fives + " femöring(ar)\r\n";
                }
                if (onecoins > 0)
                {
                    vaxelText += onecoins + " enöring(ar)\r\n";
                }

                lblnewone.Text = vaxelText;

            }
            else
            {

            }
        }


        private void closeBtn1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
