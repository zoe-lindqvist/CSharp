﻿//Programmet läser in uppgifter för ett antal säljare i en säljkår.
//
//Pseudokod:
//
// Skapa en lista för att lagra entries
// Fråga användaren hur många entries de vill lägga till
//
// För varje entry:
// - Fråga namn, personnummer, distrikt och antal sålda artiklar
// - Lägg till en ny entry med angivna uppgifter till listan
// Sortera entries i listan i fallande ordning efter antal sålda artiklar
// Skriv ut en tabell med entries till en fil och till konsolen
// - För varje entry: skriv ut namn, personnummer, distrikt och antal sålda artiklar i separata kolumner
// Räkna antalet säljare i olika försäljningsnivåer baserat på antalet sålda artiklar
// Skriv ut antalet säljare i varje försäljningsnivå till konsolen.



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
namespace Application
{


    public class Program
    {

        public static void Main()
        {


            // Fråga användaren hur många entries de vill lägga till
            Console.OutputEncoding = Encoding.UTF8;
            Console.Write("Hur många säljare önskar du att registrera? ");
            int numEntries = int.Parse(Console.ReadLine());

            // Skapa lista för att lagra entries
            List<Entry> entries = new List<Entry>();

            // Loopa igenom och hämta användarinput för varje entry
            for (int i = 0; i < numEntries; i++)
            {
                Console.WriteLine($"Säljare #{i + 1}:");
                Console.Write("Namn: ");
                string name = Console.ReadLine();
                Console.Write("Personnummer: ");
                string idNumber = Console.ReadLine();
                Console.Write("Distrikt: ");
                string areaCode = Console.ReadLine();
                Console.Write("Antal såld artiklar: ");
                int sales = int.Parse(Console.ReadLine());
                entries.Add(new Entry(name, idNumber, areaCode, sales));
            }

            // Beräkna maximala bredden på värden för varje kolumn
            int nameWidth = 15;
            int idWidth = 15;
            int areaWidth = 15;
            int salesWidth = 15;

            // Beräkna antal försäljare i varje nivå
            int numLowSales = entries.Count(entry => entry.Sales >= 0 && entry.Sales <= 50);
            int numMedSales = entries.Count(entry => entry.Sales >= 51 && entry.Sales <= 99);
            int numMedHighSales = entries.Count(entry => entry.Sales >= 100 && entry.Sales <= 199);
            int numHighSales = entries.Count(entry => entry.Sales >= 200);

            // Sortera the entries efter sålda artiklar, fallande ordning
            entries.Sort((a, b) => b.Sales.CompareTo(a.Sales));

            // Skriv ut tabell med entries
            using (StreamWriter sw = new StreamWriter("Uppgift_2_output_fil.txt"))
            {
                //Skriv ut tabell
                sw.WriteLine($"{"Namn".PadRight(nameWidth)}\t{"Prsnr".PadRight(idWidth)}\t{"Distrikt".PadRight(areaWidth)}\t{"Antal".PadRight(salesWidth)}");
                Console.WriteLine($"{"Namn".PadRight(nameWidth)}\t{"Prsnr".PadRight(idWidth)}\t{"Distrikt".PadRight(areaWidth)}\t{"Antal".PadRight(salesWidth)}");

                //Skriv ut entries för nivå 1
                foreach (Entry entry in entries) if (entry.Sales >= 0 && entry.Sales <= 50)
                    {

                        sw.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");
                        Console.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");
                    }

                // Skriv ut summering av försäljning för nivå 1
                if (numLowSales > 0)
                {
                    sw.WriteLine($"{numLowSales} säljare har nått nivå 1: 0-50 artiklar \n");
                    Console.WriteLine($"{numLowSales} säljare har nått nivå 1: 0-50 artiklar \n");
                }

                //Skriv ut entries för nivå 2
                foreach (Entry entry in entries) if (entry.Sales >= 51 && entry.Sales <= 99)
                    {

                        sw.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");
                        Console.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");

                    }

                // Skriv ut summering av försäljning för nivå 2
                if (numMedSales > 0)
                {
                    sw.WriteLine($"{numMedSales} säljare har nått nivå 1: 51-99 artiklar \n");
                    Console.WriteLine($"{numMedSales} säljare har nått nivå 1: 51-99 artiklar \n");
                }

                //Skriv ut entries för nivå 3
                foreach (Entry entry in entries) if (entry.Sales >= 100 && entry.Sales <= 199)
                    {

                        sw.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");
                        Console.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");

                    }

                // Skriv ut summering av försäljning för nivå 3
                if (numMedHighSales > 0)
                {
                    sw.WriteLine($"{numMedHighSales} säljare har nått nivå 1: 100-199 artiklar \n");
                    Console.WriteLine($"{numMedHighSales} säljare har nått nivå 1: 100-199 artiklar \n");
                }

                //Skriv ut entries för nivå 4
                foreach (Entry entry in entries) if (entry.Sales >= 200)
                    {

                        sw.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");
                        Console.WriteLine($"{entry.Name.PadRight(nameWidth)}\t{entry.IDNumber.PadRight(idWidth)}\t{entry.AreaCode.PadRight(areaWidth)}\t{entry.Sales.ToString().PadRight(salesWidth)}");

                    }

                // Skriv ut summering av försäljning för nivå 4
                if (numHighSales > 0)
                {
                    sw.WriteLine($"{numHighSales} säljare har nått nivå 4: över 199 artiklar");
                    Console.WriteLine($"{numHighSales} säljare har nått nivå 4: över 199 artiklar");
                }


            }
        }


    }


    class Entry
    {
        public string Name { get; }
        public string IDNumber { get; }
        public string AreaCode { get; }
        public int Sales { get; }

        public Entry(string name, string idNumber, string areaCode, int sales)
        {
            Name = name;
            IDNumber = idNumber;
            AreaCode = areaCode;
            Sales = sales;
        }

    }

}
