﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace assignment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Skapa klass person
        public class person
        {
            public string fornamn; public string efternamn; public string personnr;
        }



        // Metod som körs när OK-knappen klickas på
        private void btnOK_Click(object sender, EventArgs e)
        {

            //Skapa objekt i klassen person
            person personEtt= new person();

            // Hämta texten från de olika inmatningsfälten som personEtt egenskaper
            personEtt.fornamn = namnBox.Text;
            personEtt.efternamn=efternamnBox.Text;
            personEtt.personnr=personnrBox.Text;

            // Ta bort bindestrecket i personnumret
            String new_prsnmr = personEtt.personnr.Remove(6, 1);

            // Skapa en array av tecken från personnumret
            char[] chars = new_prsnmr.ToCharArray();

            // Skapa en variabel för att lagra summan av produkterna av tecknen i personnumret
            int summa = 0;

            // Loopa igenom alla tecken i personnumret
            for (int i=0; i < chars.Length; i++)
            {
                // Bestäm om det nuvarande tecknet ska multipliceras med 1 eller 2
                int multiplier = i % 2 ==0 ? 2 : 1;

                // Multiplicera tecknet med multipliern
                int product = multiplier * int.Parse(chars[i].ToString());

                // Konvertera produkten till en sträng
                String productString = product.ToString();

                // Loopa igenom varje tecken i produkten
                for (int j = 0; j < productString.Length; j++)
                {
                    // Lägg till varje tecken i produkten till summan
                    summa += int.Parse(productString[j].ToString());
                }
            }

            // Skapa en variabel för att lagra om personnumret är godkänt eller ej
            int godkand = 0;

            // Skapa en variabel för att lagra kön (tom sträng som default)
            String kon = " ";

            // Kontrollera om summan är delbar med 10
            if (summa % 10 == 0)
            {
                // Om summan är delbar med 10, sätt godkand till 1
                godkand = 1;

                // Hämta det andra sista tecknet i personnumret (som representerar kön)
                int kon_nr = int.Parse(chars[chars.Length - 2].ToString());

                // Om det andra sista tecknet är jämnt, är personen en kvinna, annars en man
                if (kon_nr % 2 == 0)
                {
                     kon = "Kvinna";
                }
                else {  kon = "Man"; }
            }


            // Om personnumret är godkänt
            if (godkand == 1)
            {
                // Visa resultatet i en gruppbox
                groupBox1.Text = "RESULTAT \n Förnamn " + personEtt.fornamn + "\n Efternamn:" + personEtt.efternamn + "\n Personnr:" + personEtt.personnr + " \n" + kon;
            }
            else
            {
                groupBox1.Text = "RESULTAT \n Personnummer felaktigt, försök igen! ";
            }
            
        }

        // Metod som körs när Avsluta-knappen klickas på
        private void btnAvsluta_Click(object sender, EventArgs e)
        {
            // Avsluta programmet
            this.Close();
        }
    }
}
